var secondary = new Array();
secondary["ID14194"] = "Auftrag bearbeiten Version 2.0";