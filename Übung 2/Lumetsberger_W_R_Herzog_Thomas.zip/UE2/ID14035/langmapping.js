var secondary = new Array();
secondary["ID14035"] = "Dokumente Version 1.0";