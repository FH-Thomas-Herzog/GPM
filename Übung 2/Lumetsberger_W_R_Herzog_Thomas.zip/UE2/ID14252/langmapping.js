var secondary = new Array();
secondary["ID14252"] = "Kunde im System erfassen Version 2.0";