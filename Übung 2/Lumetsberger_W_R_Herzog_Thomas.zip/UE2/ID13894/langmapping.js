var secondary = new Array();
secondary["ID13894"] = "Kunde im System erfassen Version 1.0";