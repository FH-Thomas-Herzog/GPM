var secondary = new Array();
secondary["ID13967"] = "Auftrag bearbeiten Version 1.0";