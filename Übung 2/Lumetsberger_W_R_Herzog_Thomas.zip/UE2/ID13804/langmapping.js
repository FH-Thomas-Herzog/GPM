var secondary = new Array();
secondary["ID13804"] = "Anfrage bearbeiten Version 1.0";