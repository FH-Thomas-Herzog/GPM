strUI_tabView = "tabular view";
strUI_graView = "graphical view";
strUI_contact = "contact person";
strUI_treeExpand = "restore tree";
strUI_treeCollapse = "collapse tree";
strUI_scrollExpand = "restore scroller";
strUI_scrollCollapse = "collapse scroller";
strUI_parentHist = "superordinated process";
strUI_noResult = "... no hits found ...";
strUI_invalidInputForSearch = "... invalid search pattern ...";
bZoom = true;
strUI_searchResults = "Search results";
strUI_foundMods = "Found models";
strUI_foundInst = "Found instances";


var sTmpModID = '';
var actTargetModID = '';

var inst_Addr = new Array();

var loadedMappings = new Array();
var loadedURLMappings = new Array();
var loadedMappingEntries = new Array();
var loadedURLMappingEntries = new Array();

function __activateView()
{
  if (!parent.control || !parent.header || !parent.menu)
  {
    window.setTimeout(" __activateView()", 100);
  }
  else
  {
    activateView();
  }
}

function setViewActive(sID)
{
  if (!parent.control)
  {
    window.setTimeout("setViewActive('" + sID + "')", 100);
  }
  else
  {
    parent.control.gActiveView = sID;
    __activateView();
  }
}

function setViewActiveCol(sID)
{
  if (!parent.header || !parent.header.document.getElementById('views_collapsed'))
  {
    window.setTimeout("setViewActiveCol('" + sID + "')", 100);
  }
  else
  {
    setViewActive(sID);
    viewsCollapsed = parent.header.document.getElementById('views_collapsed');
    viewsCollapsed.innerHTML = get_collapsed_views();
  }
}

function write_expanded_views()
{
  if (!parent.header || !parent.control || !parent.control.availableViews ||
      !parent.header.document.getElementById('viewContainer'))
  {
    window.setTimeout("write_expanded_views()", 100);
  }
  else
  {
    views = parent.control.availableViews;
    sOut = "";
    for (i=0; i<views.length; i++)
    {
      sOut += ('<a href="javascript:setViewActive(\'' + views[i] + '\')" id="' + views[i] + '" class="' + views[i] + '_l"></a>');      
    }
    cont = parent.header.document.getElementById('viewContainer');
    cont.innerHTML = sOut;
  }
}


function write_collapsed_views()
{
  document.writeln(get_collapsed_views());
}

function get_collapsed_views()
{
  sOut='';
  if (!parent.control || !parent.control.gActiveView || !parent.control.availableViews)
  {
    window.setTimeout(" get_collapsed_views()", 100);
  }
  else
  {
    views = parent.control.availableViews;
    index=-1;
    
    
    for (i=0; i<views.length; i++)
    {
      if (views[i] == parent.control.gActiveView)
      {
        
        if (i == views.length - 1)
        {
          index=0;
        }
        else
        {
          index=i+1;
        }
        break;
      }
    }
    nextView = views[index];
    
    for (i=0; i<views.length; i++)
    {
      if (views[i] == nextView)
      {
        sDisplay = 'block';
      }
      else
      {
        sDisplay = 'none';
      }
      sOut+=('<a href="javascript:setViewActiveCol(\'' + views[i] + '\')" id="' + views[i] + '" class="' + views[i] + '_l" style="display:' + sDisplay + ';margin-top:2px;"></a>');
    }
  }
  return(sOut);
}

function setClass(sObjID, sClass)
{
  if (!parent.header)
  {
    window.setTimeout("setClass('" + sObjID + "', '" + sClass + "')",100);
  }
  else
  {
    if (! parent.header.document.getElementById(sObjID))
    {
      window.setTimeout("setClass('" + sObjID + "', '" + sClass + "')",100);
    }
    else
    {
      elem = parent.header.document.getElementById(sObjID);
      if (typeof(elem) == "undefined")
      {
        window.setTimeout("setClass('" + sObjID + "', '" + sClass + "')",100);
      }
      else
      {
        elem.className = sClass;
      }
    }
  }
}

function activateView()
{
  if (!parent.control ||!parent.menu)
  {
    window.setTimeout("activateView()",100);  
  }
  else
  {
    if (!parent.control.availableViews ||
        !parent.control.availableViewPages ||
        !parent.control.gActiveView
       )
    {
      window.setTimeout("activateView()",100);  
    }
    else
    {
      views = parent.control.availableViews;
      views_tree_pages = parent.control.availableViewPages;
      for (i=0; i < views.length; i++)
      {
        if (views[i] == parent.control.gActiveView)
        {
          setClass(views[i], views[i] + "_h");
          headerPic = views[i].substring(views[i].length - 3, views[i].length);
          setClass("header_main", "boc_is_header_main_" + headerPic);
          setClass("header_main_collapsed", "boc_is_header_main_s_" + headerPic);

          var menupage = parent.menu.location.href;
          menupage = menupage.split("/");

          if (menupage[menupage.length - 1] != views_tree_pages[i])
          {
            parent.menu.location = '../menu/' + views_tree_pages[i];
          }
          actualizeTabLink();
        }
        else
        {
          setClass(views[i], views[i] + "_l");
        }
      }
    }  
  }
}

function toggleHeader()
{
  if (!parent ||  !parent.header)
  {
    window.setTimeout("toggleHeader()",100); 
  }
  else
  {
    headerFrame = parent.document.getElementById('fsmain');
    headerExpanded = parent.header.document.getElementById('header_expanded');
    headerCollapsed = parent.header.document.getElementById('header_collapsed');
    viewsCollapsed = parent.header.document.getElementById('views_collapsed');
    oNavBar = parent.header.document.getElementById("navbar");  

    if (!headerFrame || !headerExpanded || !headerCollapsed || !viewsCollapsed || !oNavBar)
    {
      window.setTimeout("toggleHeader()",100);     
    }
    else
    {
      if (gHeaderToggleMode == 1)
      {
        headerCollapsed.style.display = 'block';
        headerExpanded.style.display = 'none';
        headerFrame.rows = "60, *";
        gHeaderToggleMode = 0;
        oNavBar.style.top = 23;
      }
      else
      {
        headerCollapsed.style.display = 'none';
        headerExpanded.style.display = 'block';
        headerFrame.rows = "139, *";
        gHeaderToggleMode = 1;
        oNavBar.style.top = 102;
      }
      viewsCollapsed.innerHTML = get_collapsed_views();
      //activateView();
      if (bZoom)
      {
        parent.header.actualizeSlider();
      }    
    }
  }
}

function actualizeSlider()
{
  if (!parent.header || !parent.control)
  {
    window.setTimeout("actualizeSlider();", 100);    
  }
  else
  {
    if (!parent.header.validSlider1 || !parent.control.zoomlevel)
    {
      window.setTimeout("actualizeSlider();", 100);        
    }
    else
    {
      zoomlevel = parent.control.zoomlevel;
      nFlag = 2;
      if (zoomlevel == 50)
      {
        nFlag = 0;
      }
      else if (zoomlevel == 75)
      {
        nFlag = 1;
      }
      else
      {
        nFlag = 2;
      }

      parent.header.placeSliders()
      parent.header.validSlider1.setValue(nFlag);
    }
  }
}

function setZoomLevel(nFlag)
{
  if (!parent.control || !parent.model)
  {
    window.setTimeout("setZoomLevel(" + nFlag + ");", 100);          
  }
  else
  {
    zoomlevel = 100;
    if (nFlag == 0)
    {
      zoomlevel = 50;
    }
    else if (nFlag == 1)
    {
      zoomlevel = 75;
    }
    else
    {
      zoomlevel = 100;
    }
    parent.control.zoomlevel = zoomlevel;
    parent.model.location.reload();  
  }
}

function showZoom()
{
  if (!parent.header)
  {
    window.setTimeout("showZoom();", 100);
  }
  else
  {
    aForm = parent.header.document.getElementById("slider1form");
    aButton = parent.header.document.getElementById("Slider1Button");
    
    if (!aForm || !aButton)
    {
      window.setTimeout("showZoom();", 100);    
    }
    else
    {
      aForm.style.display = 'block';
      aButton.style.display = 'block';    
    }
  }
}

function hideZoom()
{
  if (!parent.header)
  {
    window.setTimeout("hideZoom();", 100);
  }
  else
  {
    aForm = parent.header.document.getElementById("slider1form");
    aButton = parent.header.document.getElementById("Slider1Button");
    if (!aForm || !aButton)
    {
      window.setTimeout("hideZoom();", 100);
    }
    else
    {
      aForm.style.display = 'none';
      aButton.style.display = 'none';    
    }
  }
}


function highLight(sID)
{
  if (!parent.menu)
  {
    window.setTimeout("highLight('" + sID + "');", 100);
  }
  else
  {
    if (!parent.menu.document.getElementsByName(sID))
    {
      window.setTimeout("highLight('" + sID + "');", 100);
    }
    else
    {
      hT = parent.menu.highLightT(sID);
      ecode = hT;
      if (ecode != 0)
      {
        if (!parent.control)
        {
          window.setTimeout("highLight('" + sID + "');", 100);
        }
        else
        {
          parent.control.highlighted = sID;    
          // fallback 
          parent.control.gContentReload = false;
          setViewActive('view_all');        
        }
      }    
    }
  }
}

function set_feedback(sEmail)
{
 
  if (!parent.control)
  {
    window.setTimeout("set_feedback('" + sEmail + "');", 100);
  }
  else
  {
    if (sEmail != "")
    {
      sOut = ("<nobr><a href=\"mailto:" + sEmail + "\"  onMouseOut=\"quickTipclear();\" onMouseOver=\"quickTip('" + strUI_contact + "');\"><img src=\"../img/ui/ico_pers.gif\" class=\"ico_person\"/>" + sEmail + "</a></nobr>");
    }
    else
    {
      sOut = "";   
    }
    parent.control.feedback = sOut;
    actualizeFeedback();
  }
}



function hide_resize()
{
  if (!parent.hresize)
  {
    window.setTimeout("hide_resize();", 100);  
  }
  else
  {
    if (!parent.hresize.document.getElementById('toggle') ||
        !parent.document.getElementById('fsleft')
       )
    {
      window.setTimeout("hide_resize();", 100);      
    }
    else
    {
      if (! parent.hresize.scroller_hidden)
      {
        fs = parent.document.getElementById('fsleft');    
        sRows = fs.rows;
        if (! parent.hresize.collapsed)
        {
          parent.hresize.lastSize = sRows;
          fs.rows = "*,15,0";
          parent.hresize.document.getElementById('toggle').className = "open";
          parent.hresize.collapsed = true;
          parent.hresize.scroller_hidden = true;
        }
      }
    }
  }
}

function show_resize()
{
  if (!parent.hresize)
  {
    window.setTimeout("show_resize();", 100);  
  }
  else
  {
    if (!parent.hresize.document.getElementById('toggle') ||
        !parent.document.getElementById('fsleft')
       )
    {
      window.setTimeout("show_resize();", 100);      
    }
    else
    {
      if (parent.hresize.scroller_hidden)
      {
        fs = parent.document.getElementById('fsleft');    
        sRows = fs.rows;
        if (parent.hresize.collapsed)
        {
          fs.rows = parent.hresize.lastSize;
          parent.hresize.lastSize = "";
          parent.hresize.document.getElementById('toggle').className = "close"; 
          parent.hresize.collapsed = false;
          parent.hresize.actualizeAS();
          parent.hresize.scroller_hidden = false;
        }
      }
    }
  }
}

function set_tab_link(targetID, sMType, nDir)
{
  if (!parent.control)
  {
    window.setTimeout("set_tab_link('" + targetID + "', '" + sMType + "', " + nDir + ");", 100);
  }
  else
  {
    if (nDir == 1)
    {
      sCaption = strUI_tabView;
      sClass = "button_tab";
    }
    else
    {
      sCaption = strUI_graView;
      sClass = "button_graph";
    }
    sOut = ("<a class=\"" + sClass + "\"href=\"../" + targetID + "/" + targetID);
    if (nDir == 1)
    {
      sOut += "1";
    }
    sOut += (".htm\" alt=\"" + sCaption + "\" target=\"model\"" +
           "onMouseOver=\"quickTip('" + sCaption + "');\" onMouseOut=\"quickTipclear();\"></a>");
    
    parent.control.tablink = sOut;
    parent.control.tabmtype = sMType;
    actualizeTabLink();
  }
}

function deactivateTabLink()
{
  if (!parent.control)
  {
    window.setTimeout("deactivateTabLink();", 100);  
  }
  else
  {
    parent.control.tablink = "";
    parent.control.tabmtype = "";  
  }
}

function actualizeFeedback()
{
  if (!parent.header || !parent.control)
  {
    window.setTimeout("actualizeFeedback();", 100);
  }
  else
  {   
    oFeed = parent.header.document.getElementById("tools_feedback");
    if (!oFeed || !parent.control.feedback)
    {
      window.setTimeout("actualizeFeedback();", 100);
    }
    else
    {
      oFeed.innerHTML = parent.control.feedback;
    }    
  }
}


function startEvents()
{
  document.events = true;
}


function actualizeTabLink()
{

  if (!parent.header ||!parent.control)
  {
    window.setTimeout("actualizeTabLink();", 100);
  }
  else
  {
    if (!parent.header.document.getElementById("tools_tab"))
    {
      window.setTimeout("actualizeTabLink();", 100);    
    }
    else
    {
      if (!parent.control.tablink)
      {
        parent.control.tablink = "";
        parent.control.tabmtype = "";
      }
      curView = parent.control.gActiveView;
      curTabMType = parent.control.tabmtype;
      aPMTypes = parent.control.aPoolMTypes;

      bTabular = false;
      for (key in aPMTypes)
      {
        if (curTabMType == aPMTypes[key])
        {
          bTabular = true;
          break;
        }
      }
      if (bTabular)
      {
        parent.header.document.getElementById("tools_tab").innerHTML = parent.control.tablink;    
      }
      else
      {
        parent.header.document.getElementById("tools_tab").innerHTML = "";
      }
    }
  } 
}

function setModelName(sModelname)
{
  if (!parent.header)
  {
    window.setTimeout("setModelName('" + sModelname + "');", 100);
  }
  else
  {
    if (!parent.header.document.getElementById("tools_modelname"))
    {
      window.setTimeout("setModelName('" + sModelname + "');", 100);    
    }
    else
    {
      parent.header.document.getElementById("tools_modelname").innerHTML = ("<nobr>" + maskTags(sModelname) + "</nobr>");
    }
  }
}


bResizing = false;
nResizeWidth = 15;

function GetResizeMouse(Event)
{
  if (moz)
  {
    oEvent = Event;
  }
  else
  {
    oEvent = event;
  }
  if (!oEvent)
  {
    return;
  }
  else
  {
    if (!parent.document.getElementById('treecontainer'))
    {
      window.setTimeout("GetResizeMouse(Event);", 100);  
    }
    else
    {
      newX = oEvent.clientX;
      newY = oEvent.clientY;
      if (bResizing)
      {
        treeContainer = parent.document.getElementById('treecontainer');    
        sCols = treeContainer.cols;
        aCols = sCols.split(",");

        nCols = eval(aCols[0]) + newX - (nResizeWidth/2);
        if (nCols > nResizeWidth)
        {
          sCols = nCols + ",*";
          treeContainer.cols = sCols;
        }
      }
    }
  }
}

function hGetResizeMouse(Event)
{
  if (moz)
  {
    oEvent = Event;
  }
  else
  {
    oEvent = event;
  }
  if (!oEvent)
  {
    return;
  }
  else
  {
    if (!parent.document.getElementById('fsleft'))
    {
      window.setTimeout("hGetResizeMouse(Event);", 100);      
    }
    else
    {
      newX = oEvent.clientX;
      newY = oEvent.clientY;
      if (bResizing)
      {
        fs = parent.document.getElementById('fsleft');
        sRows = fs.rows;
        aRows = sRows.split(",");

        nRows = eval(aRows[2]) - newY + (nResizeWidth/2);
        if (nRows > nResizeWidth)
        {
          sRows = "*,15," + nRows;
          fs.rows = sRows;
        }
      }
    }
  }
}

/* for vertical resizing bar*/

function startResize()
{
  bResizing = true;
}

function endResize()
{
  if (!parent.model)
  {
    window.setTimeout("endResize();", 100);        
  }
  else
  {
    if (bResizing)
    {
      parent.model.actualizeAS();
    }
    bResizing = false;
  }
}

function cancelResize()
{
  if (moz)
  {  
    endResize();
  }
}

function toggle_resize()
{
  treeContainer = parent.document.getElementById('treecontainer');    
  if (!treeContainer || !document.getElementById('toggle'))
  {
    window.setTimeout("toggle_resize();", 100);          
  }
  else 
  {
    sCols = treeContainer.cols;
    if (! collapsed)
    {
      lastSize = sCols;
      treeContainer.cols = "15,*";
      document.getElementById('toggle').className = "open";
      collapsed = true;
    }
    else
    {
      treeContainer.cols = lastSize;
      lastSize = "";
      document.getElementById('toggle').className = "close"; 
      collapsed = false;
      actualizeAS();
    }
  }
}

/* for horizontal resizing bar*/

function hstartResize()
{
  bResizing = true;
}

function hendResize()
{
  if (!parent.model)
  {
    window.setTimeout("hendResize();", 100);          
  }
  else
  {
    if (bResizing)
    {
      parent.model.actualizeAS();
    }
    bResizing = false;
  }
}

function hcancelResize()
{
  if (moz)
  {  
    hendResize();
  }
}

function htoggle_resize()
{
  fs = parent.document.getElementById('fsleft');    
  if (!fs || !document.getElementById('toggle'))
  {
    window.setTimeout("htoggle_resize();", 100);          
  }
  else
  {
    sRows = fs.rows;
    if (! collapsed)
    {
      lastSize = sRows;
      fs.rows = "*,15,0";
      document.getElementById('toggle').className = "open";
      collapsed = true;
    }
    else
    {
      fs.rows = lastSize;
      lastSize = "";
      document.getElementById('toggle').className = "close"; 
      collapsed = false;
      actualizeAS();
    }
  }
}

function quickTip(sInfo)
{  
  if (!parent.header)
  {
    window.setTimeout("quickTip('" + sInfo + "');", 100);
  }
  else
  {
    qt = parent.header.document.getElementById('tools_quicktip'); 
    if (!qt)
    {
      window.setTimeout("quickTip('" + sInfo + "');", 100);    
    }
    else
    {
      qt.innerHTML = "<nobr><img src=\"../img/ui/info.gif\"><span class=\"tools_quicktip_qt\">" + sInfo + "</span><nobr>" ;
    }
  }
}

function quickTipclear()
{  
  if (!parent.header)
  {
    window.setTimeout("quickTipclear();", 100);
  }
  else
  {
    qt = parent.header.document.getElementById('tools_quicktip'); 
    if (!qt)
    {
      window.setTimeout("quickTipclear();", 100);    
    }
    else
    {  
      qt.innerHTML = "";
    }
  }
}

function DoquickTip(dir)
{
  if (collapsed)
  {
    if (dir == "v")
    {
    sInfo = strUI_treeExpand;
  }
  else
  {
      sInfo = strUI_scrollExpand;
    }
  }
  else
  {
    if (dir == "v")
    {
    sInfo = strUI_treeCollapse;
  }
    else
    {
      sInfo = strUI_scrollCollapse;
    }
  }
  quickTip(sInfo);
}

function setHistory()
{
  sOut = "";
  if (!parent.header || !parent.control)
  {
    window.setTimeout("setHistory();", 100);
  }
  else
  {
    if (!parent.control.gActiveView || !parent.header.document.getElementById('tools_history'))
    {
      window.setTimeout("setHistory();", 100);    
    }
    else
    {
      if ((parent.control.gActiveView == "view_pro") && (bpHistory.length > 1))
      {
        for (i = 1; i < bpHistory.length; i++)
        {
          sOut += ("<img src=\"../img/ui/hist_sep.gif\" class=\"hist_sep\"></span><a onMouseOver=\"quickTip('" + strUI_parentHist + "');\" onMouseOut=\"quickTipclear();\" href=\"javascript:loadPageDbl('" + bpHistory[i][0] + "', 'ID', 'model', '');\">" + bpHistory[i][1] + "</a>");  
        }
      }
      if (sOut != "")
      {
        sOut = "[ " + sOut + " ]";
      }
      hist = parent.header.document.getElementById('tools_history'); 
      hist.innerHTML = "<span class=\"tools_history\">" + sOut + "</span>";
    }
  }
  parent.control.bphistory = "<span class=\"tools_history\">" + sOut + "</span>";
}

function getZoom()
{
  if (!parent.control)
  {
    window.setTimeout("getZoom();", 100);  
  }
  else
  {
    if (!parent.control.zoomlevel)
    {
      window.setTimeout("getZoom();", 100);      
    }
    else
    {
      return parent.control.zoomlevel;
    }      
  }  
}

function analyzeid(id)
{
  act_index = get_entry_by_addr(id);
  instframe = false;
  modframe = false;
  message = false;
  
  //----------------------------------------------------
  // SEARCH BY URL
  //
  // found addr
  //----------------------------------------------------
  if (act_index != -1)
  {
    process_index(act_index);
  }
  //----------------------------------------------------
  // SEARCH BY NAME
  //
  // 
  //----------------------------------------------------
  else
  {
    act_index = get_entry_by_name(id);
    if (act_index != -1)
    {
      process_index(act_index);
    }
    else
    {
      message = ("Target <b>'" + id + "'</b> unknown.<br>No such url or name found!");
    }
  }
}

function process_index(act_entry)
{
  act_info = (unescape(pageinfo[act_entry]));  
  b_flag = get_token(act_info, 0);
  // param is instance
  if (b_flag == 0)
  {
    instframe = unescape(pageaddr[act_entry]);
    modid = get_token(act_info, 3);
    modurl = get_addr_of_modid(modid);
    modframe = modurl;
  }
  // param is model
  else if (b_flag == 1)
  {
    instframe = false;
    modframe = unescape(pageaddr[act_entry]);
  }
  // param is invalid
  else
  {
    message = ("invalid pageinfo <" +act_info + ">");
  }
}

function get_token(string, index)
{
  a_token_set = string.split("|||");
  if (a_token_set[index])
  {
    return(a_token_set[index]);
  }
  else
  {
    //[GSp, 2006.05.18]
    //changed return value from false to ""
    return "";
  }
}

function token_count(string)
{
  a_token_set = string.split("|||");
  return a_token_set.length;
}


function get_entry_by_addr(id)
{
  //[GSp, 2007.08.22] changed function for ADONIS 3.9 UL2
  index = -1;
  for (i=0;i<pageinfo.length;i++)
  {   
    act_info = unescape(pageinfo[i]);    
    act_id = get_token(act_info, 1);
    
    if (act_id == id)
    {
      return(i);
    } 
  }
  return(index);
}

function unmask(sIn)
{
  sIn = sIn.replace(/&#92;/g,"\\");
  sIn = sIn.replace(/&#34;/g,"\"");
  sIn = sIn.replace(/&lt;/g,"<");
  sIn = sIn.replace(/&gt;/g,">");
  // Polish characters [PKO]
  sIn = sIn.replace(/%B3/g,"�"); 
  sIn = sIn.replace(/%A3/g,"�"); 
  sIn = sIn.replace(/%BF/g,"�"); 
  sIn = sIn.replace(/%AF/g,"�"); 
  sIn = sIn.replace(/%9F/g,"�"); 
  sIn = sIn.replace(/%8F/g,"�"); 
  sIn = sIn.replace(/%9C/g,"�"); 
  sIn = sIn.replace(/%8C/g,"�"); 
  sIn = sIn.replace(/%E6/g,"�"); 
  sIn = sIn.replace(/%C6/g,"�");
  sIn = sIn.replace(/%EA/g,"�"); 
  sIn = sIn.replace(/%CA/g,"�"); 
  sIn = sIn.replace(/%B9/g,"�"); 
  sIn = sIn.replace(/%A5/g,"�"); 
  sIn = sIn.replace(/%F1/g,"�"); 
  sIn = sIn.replace(/%D1/g,"�");
  // Czech characters [PKO]
  sIn = sIn.replace(/%EC/g,"�");   
  sIn = sIn.replace(/%CC/g,"�");    
  sIn = sIn.replace(/%9A/g,"�");      
  sIn = sIn.replace(/%8A/g,"�");  
  sIn = sIn.replace(/%E8/g,"�");   
  sIn = sIn.replace(/%C8/g,"�");     
  sIn = sIn.replace(/%F8/g,"�");   
  sIn = sIn.replace(/%D8/g,"�");  
  sIn = sIn.replace(/%9E/g,"�");  
  sIn = sIn.replace(/%8E/g,"�");        
  sIn = sIn.replace(/%FD/g,"�");   
  sIn = sIn.replace(/%DD/g,"�");       
  sIn = sIn.replace(/%E1/g,"�");   
  sIn = sIn.replace(/%C1/g,"�");     
  sIn = sIn.replace(/%ED/g,"�");   
  sIn = sIn.replace(/%CD/g,"�");    
  sIn = sIn.replace(/%E9/g,"�");   
  sIn = sIn.replace(/%C9/g,"�");     
  sIn = sIn.replace(/%F3/g,"�");   
  sIn = sIn.replace(/%D3/g,"�");          
  sIn = sIn.replace(/%FA/g,"�");  
  sIn = sIn.replace(/%DA/g,"�");     
  sIn = sIn.replace(/%F9/g,"�");     
  sIn = sIn.replace(/%D9/g,"�");    
  sIn = sIn.replace(/%9D/g,"�");
  sIn = sIn.replace(/%8D/g,"�");               
  sIn = sIn.replace(/%EF/g,"�");
  sIn = sIn.replace(/%CF/g,"�");
  sIn = sIn.replace(/%F2/g,"�");
  sIn = sIn.replace(/%D2/g,"�"); 
  // Slovak characters [PKO]       
  sIn = sIn.replace(/%BE/g,"�");
  sIn = sIn.replace(/%BC/g,"�"); 
  sIn = sIn.replace(/%F4/g,"�");
  sIn = sIn.replace(/%D4/g,"�");
  // Hungarian characters [PKO]       
  sIn = sIn.replace(/%F5/g,"�");
  sIn = sIn.replace(/%D5/g,"�"); 
  sIn = sIn.replace(/%FB/g,"�");
  sIn = sIn.replace(/%DB/g,"�");       
  return sIn;
}

function get_entry_by_name(name)
{
  index = -1;
  for (i=0;i<pageinfo.length;i++)
  {   
    act_info = unescape(pageinfo[i]);    
    b_flag = get_token(act_info, 0);
    act_name = get_token(act_info, 2);
    act_name = unmask(act_name);
    
    if (act_name == name)
    {
      return(i);
    } 
  }
  return(index);
}

function get_addr_of_modid(modid)
{
  addr = false;
  for (i=0;i<pageinfo.length;i++)
  {
    a_act_info = unescape(pageinfo[i]);
    b_flag = get_token(a_act_info, 0);
    if (b_flag == 1)
    {
      s_modid = get_token(a_act_info, 1);
      if (s_modid == modid)
      {
        addr = unescape(pageaddr[i]);
        return(addr);
      }
    }
  }
  return (addr);
}

function loadUrl(url, target)
{  
  oMod = parent.model;
  oCon = parent.control;
  if (!oCon || !oMod)
  {
    window.setTimeout("loadUrl('" + url + "','" + target + "');", 100);  
  }
  else
  { 
    if (target == "mod")
    {
      parent.model.location.href = url; 
    }
    else
    {
      if (parent.control.awin != 0)
        parent.control.awin.close();
      parent.control.awin = window.open(url, "InstanceWindow", "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes,left=0,top=300");
    }
  }
}

function loadUrlN(url, target)
{  
  bReload = false;
  // to avoid firefox bug
  if (window.name == "InstanceWindow")
  {
    bReload = true;
  }

  id = url.substring(url.lastIndexOf("/")+1, url.length);
  if (id == 'undefined')
  {
    return;
  }
  if (window == top)
  {
    oObj = opener; 
  }
  else
  {
    oObj = parent;
  }
  pageAdress = url;    

  if (pageAdress == "")
  {
    return 0;
  }

  if (target == "InstanceWindow")
  {
    if (!oObj.parent.control)
    {
      window.setTimeout("loadUrlN('" + url + "', '" + target + "');", 100);    
    }
    else
    {
      oObj.top.current_instance = name;
      if (bReload == true)
      {
        window.location.href = pageAdress;
        window.focus();
      }
      else
      {
        oObj.parent.control.awin = window.open(pageAdress, "InstanceWindow", "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes");
        oObj.parent.control.awin.focus();
      }      
    }
  }
  else
  {
    if (!parent.model)
    {
      window.setTimeout("loadUrlN('" + url + "', '" + target + "');", 100);
    }
    else
    {
      parent.model.location.href = pageAdress;
    }
  }
}

function url_jump()
{
  url_mod = "";
  url_inst = "";
  
  var idString = location.search;
  idString = unescape(idString);
  if (idString.length > 0)
  {
    var id = idString.substring(4, idString.length);
    analyzeid(id);

    if (typeof modframe != "undefined")
    {
      url_mod = modframe;
    }
    if (typeof instframe != "undefined")
    {
      url_inst = instframe;
    }

    if (url_inst == "" && url_mod == "")
    {
    }
    else
    {
      if (url_mod != "")
      {
        loadUrl(url_mod, 'mod');
      }
      if (url_inst != "")
      {
        window.setTimeout("loadUrl('" + url_inst + "', 'inst');", 1000);
      }
    }
  }
}

function form_jump(sName, bFragment)
{
  aResultLinksMod  = new Array();
  aResultLinksInst = new Array();
  aResultNames     = new Array();
  
  index = -1;
  var bFoo = false;
  
  for (i=0;i<pageinfo.length;i++)
  {   
    temp = unmask(pageinfo[i]); 
    act_info = unescape(temp);          
    b_flag = get_token(act_info, 0);
    act_name = get_token(act_info, 2);
    
    //perform string comparison depending on whether fragment search is checked or not
    if (bFragment)
      bFoo = ( (unmask(act_name).toLowerCase()).indexOf(sName.toLowerCase()) > -1 );
    else
      bFoo = (unmask(act_name) == sName);

    if (bFoo)
    {
      aResultNames[aResultNames.length] = act_name;

      if (b_flag == 1)
      {
        // this is a model link
        aResultLinksMod[aResultLinksMod.length]   = pageaddr[i];
        aResultLinksInst[aResultLinksInst.length] = "";
      }
      else
      {
        // this is an instance link
        sModelid = get_token(act_info, 3);
        aResultLinksMod[aResultLinksMod.length]   = sModelid + "/" + sModelid + ".htm";
        aResultLinksInst[aResultLinksInst.length] = pageaddr[i];
      }
    } 
  }
  return ActualizeAndPrintSearchResults(aResultLinksMod, aResultLinksInst, aResultNames);
}

function ActualizeAndPrintSearchResults(aResultLinksMod, aResultLinksInst, aResultNames)
{
  if (!parent.control || !parent.model)
  {
    window.setTimeout("ActualizeAndPrintSearchResults(aResultLinksMod, aResultLinksInst, aResultNames);", 100);  
  }
  else
  {
    if (typeof(parent.control.searchResults) != "string")
    {
      window.setTimeout("ActualizeAndPrintSearchResults(aResultLinksMod, aResultLinksInst, aResultNames);", 100);  
    }
    else
    {
      if (aResultNames.length == 1)
      {
        if (!((aResultNames.length == aResultLinksMod.length) && (aResultLinksMod.length == aResultLinksInst.length)))
          return false;


        if (aResultLinksInst[0] == "")
        {
          // this is a model
          loadUrl('../' + aResultLinksMod[0], 'mod');
          return true;
        }
        else
        {
          // this is an instance
          loadUrl('../' + aResultLinksMod[0], 'mod');
          window.setTimeout("loadUrl('" + aResultLinksInst[0] + "', 'inst');", 500);
          return true;
        }
      }

      if (aResultNames.length > 1)
      {
        if (!((aResultNames.length == aResultLinksMod.length) && (aResultLinksMod.length == aResultLinksInst.length)))
          return false;


        // sort output
        var aSortedOutput = new Array();

        // build array for sorting
        for (i=0;i<aResultNames.length;i++)
        {   
          aSortedOutput[aSortedOutput.length] = aResultNames[i] + "" + aResultLinksMod[i] + "" + aResultLinksInst[i];
        }
        // sort
        aSortedOutput.sort();


        // OUTPUT
        sLongOutput = "";
        sOutputModels = "";
        sOutputInstances = "";
        nModelCounter = 0;
        nInstanceCounter = 0;

        for (i=0;i<aSortedOutput.length;i++)
        {   
          sCurrLine = aSortedOutput[i];
          posSep1 = sCurrLine.indexOf("");
          posSep2 = sCurrLine.lastIndexOf("");
          sCurrName     = sCurrLine.slice(0, posSep1);
          sCurrLinkMod  = sCurrLine.slice(posSep1 + 1, posSep2);
          sCurrLinkInst = sCurrLine.slice(posSep2 + 1, sCurrLine.length);

          if (sCurrLinkInst == "")
          {
            // this is a model
            sOutputModels += "&nbsp;<a href=\"../" + sCurrLinkMod + "\">" + sCurrName + "</a><br>";
            nModelCounter++;
          }
          else
          {
            // this is an instance
            sOutputInstances += "&nbsp;<a href=\"javascript:loadUrlN('../" + sCurrLinkInst + "', 'InstanceWindow');\">" + sCurrName + "</a><br>";
            nInstanceCounter++;
          }
        }

        if (sOutputModels != "")
          sLongOutput += "<br><div class=\"search_header1\">" + strUI_foundMods + " (" + nModelCounter + ")</div>" + sOutputModels;

        if (sOutputInstances != "")
          sLongOutput += "<br><div class=\"search_header1\">" + strUI_foundInst + " (" + nInstanceCounter + ")</div>" + sOutputInstances;
              
        parent.control.searchResults = sLongOutput;
        parent.model.location.href = "../misc/boc_is_empty.htm";

        return true;
      }
      else
      {
        noResults();
        return false;
      }    
    }
  }
}

function noResults()
{
  if (!parent.control || !parent.model)
  {
    window.setTimeout("noResults();", 100);    
  }
  else
  {
    sLongOutput = "<br><div class=\"search_header1\">" + strUI_noResult + "</div>";
    parent.control.searchResults = sLongOutput;
    parent.model.location.href = "../misc/boc_is_empty.htm";
  }
}

function invalidInputForSearch()
{
  if (!parent.control || !parent.model)
  {
    window.setTimeout("invalidInputForSearch();", 100);    
  }
  else
  {
    sLongOutput = "<br><div class=\"search_header1\">" + strUI_invalidInputForSearch + "</div>";
    parent.control.searchResults = sLongOutput;
    parent.model.location.href = "../misc/boc_is_empty.htm";
  }
}

function LoadSearchResults()
{
  if (!parent.control)
  {
    window.setTimeout("LoadSearchResults();", 100);  
  }
  else
  {
    sRes = parent.control.searchResults;
    if (typeof(sRes) != "string")
    {
      window.setTimeout("LoadSearchResults();", 100);  
    }
    else
    {
      oOutputDiv = document.getElementById("searchResults");
      {
        if (!oOutputDiv)
        {
          window.setTimeout("LoadSearchResults();", 100);  
        }
        else
        {
          oOutputDiv.innerHTML = sRes;
        }      
      }
    }
  }
}


function refreshSearchResult()
{
  if (!parent.control)
  {
    window.setTimeout("refreshSearchResult();", 100);  
  }
  else
  {
    parent.model.location.href = "../misc/boc_is_empty.htm";
  }
}


function search_mask()
{
  if (!parent.menu || !parent.resize)
  {
    window.setTimeout("search_mask();", 100);      
  }
  else
  {
    sMask = parent.menu.document.getElementById('search_mask');
    sIn = parent.menu.document.getElementById('sin');
    if (!sMask || !sIn)
    {
      window.setTimeout("search_mask();", 100);      
    }
    else
    {
      sMask.style.display = "block";
      sIn.focus();    
      if (parent.resize.collapsed)
      {
        parent.resize.toggle_resize();
      }    
    }
  }
}

function close_search()
{
  if (!parent.menu)
  {
    window.setTimeout("close_search();", 100);      
  }
  else
  {
    sMask = parent.menu.document.getElementById('search_mask');
    if (!sMask)
    {
      window.setTimeout("close_search();", 100);      
    }
    else
    {
      sMask.style.display = "none";
    }
  }
}

function start_search()
{
  if (!parent.menu)
  {
    window.setTimeout("close_search();", 100);      
  }
  else
  {
    sIn = parent.menu.document.getElementById('sin');
    fragment = parent.menu.document.getElementById('fragment');
    
    if (!sIn || !fragment)
    {
      window.setTimeout("start_search();", 100);          
    }
    else
    {
      //test for valid input
      re = new RegExp(/^\s*$/);
      if (re.test(sIn.value))
      {
        invalidInputForSearch();
        return;
      }    

      form_jump(sIn.value, fragment.checked);
        sIn.focus(); 
    }
  }
}

//[GSp, 2007.05.15] - 3.9 UL1 HF2
function resolveName(sInstID)
{
  if ( typeof(secondary) == "undefined" )
  {
    window.setTimeout("resolveName('" + sInstID + "');", 100);
  }
  else
  {
    // inst undefined -> so mapping file has just been loaded
    if (typeof(loadedMappingEntries[sInstID] == "undefined"))
    {
      // copy entries in global list to avoid multiple loading of
      // of mapping file

      for (var i in secondary)
      {
        loadedMappingEntries[i] = secondary[i];
      }    
    }

    sName = loadedMappingEntries[sInstID];
    if (sName == "")
    {
      return "-- no name specified --";
    }  
    return sName;
  }
}

function dynLoad(sModID)
{  
  sTmpModID = sModID;
  // if needed mapping has not been loaded
  if (typeof(loadedMappings[sModID]) == "undefined")
  {
    // load it !
    body = document.getElementById("dynamic");
    if (!body)
    {
      window.setTimeout("dynLoad('" + sModID + "');", 100);              
    }
    else
    {
      var inst_file = "../" + sModID + "/langmapping.js";
      loadedMappings[sModID] = document.createElement("script");
      loadedMappings[sModID].type = "text/javascript";
      loadedMappings[sModID].src = inst_file;
      body.appendChild(loadedMappings[sModID]);
    }
  }
}

//[GSp, 2007.05.15] - 3.9 UL1 HF2
function resolveAndDefineURL(sInstID, sModID, sParamName)
{
  if ( typeof(inst_Addr[sInstID]) == "undefined")
  {
    window.setTimeout("resolveAndDefineURL('" + sInstID + "', '" + sModID  + "', '" + sParamName + "')",100);
  }
  else
  {
    // inst undefined -> so mapping file has just been loaded
    if (typeof(loadedURLMappingEntries[sInstID] == "undefined"))
    {
      // copy entries in global list to avoid multiple loading of
      // of mapping file
      for (var i in inst_Addr)
      {
        loadedURLMappingEntries[i] = inst_Addr[i];
      }    
    }

    sURL = "../" + sModID + "/" + loadedURLMappingEntries[sInstID];

    eval(sParamName + " = sURL;");

    return sURL;
  }
}

function resolveURL(sInstID, sModID)
{
  // inst undefined -> so mapping file has just been loaded
  if (typeof(loadedURLMappingEntries[sInstID] == "undefined"))
  {
    // copy entries in global list to avoid multiple loading of
    // of mapping file
    for (var i in inst_Addr)
    {
      loadedURLMappingEntries[i] = inst_Addr[i];
    }    
  }

  sURL = "../" + sModID + "/" + loadedURLMappingEntries[sInstID];

  return sURL;
}

function dynLoadURL(sModID)
{  
  sTmpModID = sModID;
  // if needed mapping has not been loaded
  if (typeof(loadedURLMappings[sModID]) == "undefined")
  {
    // load it !
    body = document.getElementById("dynamic");
    if (!body)
    {
      window.setTimeout("dynLoadURL('" + sModID + "');", 100);              
    }
    else
    {
      var inst_file = "../" + sModID + "/instances.js";
      loadedURLMappings[sModID] = document.createElement("script");
      loadedURLMappings[sModID].type = "text/javascript";
      loadedURLMappings[sModID].src = inst_file;
      body.appendChild(loadedURLMappings[sModID]);
    }
  }
}
