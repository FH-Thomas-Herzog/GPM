
latest = "6.2.3";
recommended_versionIE = "5";
recommended_versionNS = "4.75";

is_latest_beta = false;

languagesq = new Object;
languagesq["un"] = "(Unknown language)";
languagesq["cn"] = "(Chinese (simp.) language)";
languagesq["cs"] = "(Czech language)";
languagesq["da"] = "(Danish language)";
languagesq["de"] = "(Deutsch)";
languagesq["el"] = "(Greek language)";
languagesq["en"] = "(English language)";
languagesq["es"] = "(Spanish language)";
languagesq["fc"] = "(French (Canada) language)";
languagesq["fi"] = "(Finnish language)";
languagesq["fr"] = "(French language)";
languagesq["hu"] = "(Hungarian language)";
languagesq["it"] = "(Italian language)";
languagesq["ja"] = "(Japanese language)";
languagesq["ko"] = "(Korean language)";
languagesq["nl"] = "(Dutch language)";
languagesq["no"] = "(Norwegian language)";
languagesq["pl"] = "(Polish language)";
languagesq["pt"] = "(Brazilian Portuguese language)";
languagesq["ru"] = "(Russian language)";
languagesq["sv"] = "(Swedish language)";
languagesq["tr"] = "(Turkish language)";
languagesq["tw"] = "(Chinese (trad.) language)";
languagesq["uk"] = "(English (UK) language)";
languagesq["de-de"] = "(Deutsch)"
languagesq["en-gb"] = "(English (UK) language)";
languagesq["en-us"] = "(English language)";
languagesq["es-es"] = "(Spanish language)";
languagesq["fr-fr"] = "(French language)";
languagesq["ja-jp"] = "(Japanese language)";

lang = "un";
Component = "Unknown browser";
platform = "Unknown platform";
OS = "";
version = parseFloat(navigator.appVersion);
UA = navigator.userAgent;
ua = navigator.userAgent.toLowerCase();

// Language
if (((start = ua.indexOf("[")) > 0) &&
    ((end = ua.indexOf("]")) == (ua.indexOf("[") + 3))){
  language = ua.substring(start+1, end);
} else if (navigator.language) {
  language = navigator.language.toLowerCase();
} else if (navigator.userLanguage) {
  language = navigator.userLanguage.toLowerCase();
}
if (languagesq[language]) {
  lang = language;
}

// OS
if (((ua.indexOf("ppc") > 0) && (ua.indexOf("mac") > 0))
    || (ua.indexOf("mac_power") > 0)) {
//  if (ua.indexOf("os x")) {
//    OS = "macosx";
//  } else {
    OS = "macppc";
//  }
} else if ((ua.indexOf("linux 2.2") > 0)
     || (ua.indexOf("netscape6") && ua.indexOf("linux") > 0)) {
  OS = "linux2.2";
} else if (ua.indexOf("win") > 0) {
  OS = "win32";
}

// Other info
start = UA.indexOf('(') + 1;
end = UA.indexOf(')');
str = UA.substring(start, end);
info = str.split('; ');

if (ua.indexOf('msie') != -1) {
  platform = info[2];
  Component = navigator.appName;
  str = info[1].substring(5, info[1].length);
  version = parseFloat(str);
} else if ((start = ua.indexOf("netscape6")) > 0) {
  if (info[0].toLowerCase() == "windows") {
    platform = info[2];
  } else {
    platform = info[0] + " " + info[2];
  }
  Component = "Netscape";
  version = ua.substring(start+10, ua.length);
  if ((start = version.indexOf("b")) > 0 ) {
    pr = version.substring(start+1,version.length);
    str = version.substring(0,version.indexOf("b"));
    version = str + " Preview Release " + pr;
  }

} else if ((start = ua.indexOf("netscape/7")) > 0) {
  if (info[0].toLowerCase() == "windows") {
    platform = info[2];
  } else {
    platform = info[0] + " " + info[2];
  }
  Component = "Netscape";
  version = ua.substring(start+9, ua.length);
  if ((start = version.indexOf("b")) > 0 ) {
    pr = version.substring(start+1,version.length);
    str = version.substring(0,version.indexOf("b"));
    version = str + " Preview Release " + pr;
    is_latest_beta = true;
  }

} else {
  if(info[2]) {
    if (info[0].toLowerCase() == "windows") {
      platform = info[2];
    } else {
      platform = info[0] + " " + info[2];
    }
  } else {
    platform = info[0];
  }
  if (ua.indexOf("gecko") > 0) {
    Component = "Mozilla";
  } else if (ua.indexOf("nav") > 0) {
    Component = "Netscape Navigator";
  } else {
    Component = "Netscape Communicator";
  }
}
// Some formatting
if ((platform.indexOf("NT") != -1) && (platform.indexOf("5.1") != -1)) {
  platform = "Windows XP";
}
if (parseInt(version) == parseFloat(version)) {
  version = version + ".0";
}

// function to determine if browser is at least 5.xx
function isUptodate() {
  this_rec_version = (Component.indexOf("Microsoft")==0) ? recommended_versionIE : recommended_versionNS;
  if (version>=this_rec_version) {
    return true;
  } else {
    return false;
  }
}

function returnCurrentBrowser() {
  return Component + " " + version + " " + languagesq[lang];
}

function returnCurrentOS() {
  return platform;
}

function showUpdateInfo() {
  //alert("nav= " + nav + "\nold= " + old + "\niex= " + iex + "\nmoz= " + moz + "\nope= " + ope + "\nlayer= " + layer);
  b = window.open("BrowserCheck.htm", "BrowserCheck", "dependent=yes,height=300,width=400,left=200,top=120,location=no,menubar=no,scrollbars=no,status=no,toolbar=no");
    b.focus();
}

// ***********************************************************�
// functions to determine the actual Java Virtual Machine

function setIEJvm( vendor, version ) {
	window.location.href = window.location.href + "?jvm=" + version;
}

function loadBOCTree() {
  var newtree=false;
  if ((moz==true ) || (nav==true))
  {
    if (!(document.layers)) {
       for(var i=0; i<navigator.plugins.length; i++)
       {
         if (navigator.plugins[i].description.substring(0,16)== "Java Plug-in 1.3")
         {
           newtree=true;
         }
         if (navigator.plugins[i].description.substring(0,16)== "Java Plug-in 1.4")
         {
           newtree=true;
         }
         if (navigator.plugins[i].description.substring(0,22)== "Sun's Java(tm) Plug-in") // Netscape 6.x
         {
           newtree=true;
         }
       	 if(newtree) break;
       }
    }
  } else if (iex == true) {
	if(top.location.href.indexOf("?jvm=") > 0) {
		var iexJVersion = top.location.href.substring(top.location.href.indexOf("?jvm=")+5);
		if(iexJVersion.indexOf("1.3.") >= 0 || iexJVersion.indexOf("1.4.") >= 0) {
			newtree=true;
		}
	}

  }
  return newtree;
}


// ************************************************************
// variables that should be used to specify the current browser
var nav=false;    // Netscape ?
var iex=false;    // Internet Explorer ?
var moz=false;    // Mozilla ?
var ope=false;    // Opera ?
var layer=false;  // only true with old layer model browsers (e.g. Netscape 4.x !!)
var old=false;    // is it a browser of a version higher than the recommended?
if(returnCurrentBrowser().substring(0,8)=="Netscape"){
  nav=true;
  isUptodate()?old=false:old=true;
  (document.layers)?layer=true:layer=false;
} else if(returnCurrentBrowser().substring(0,9)=="Microsoft"){
  iex=true;
  isUptodate()?old=false:old=true;
} else if(returnCurrentBrowser().substring(0,7)=="Mozilla") {
  moz=true;
} else if(returnCurrentBrowser().substring(0,5)=="Opera") {
  ope=true;
}

