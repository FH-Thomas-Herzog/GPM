var b_closetree = false;

var pfeil_auf = '../img/treeimgs/minus.gif';
var pfeil_zu = '../img/treeimgs/plus.gif';
var folder_zu = '../img/treeimgs/folder_close.gif';
var folder_auf = '../img/treeimgs/folder_open.gif';

var current_instance;

var opensubfolders=new Array();


function closeAllSubElems(elem)
{
  var element = document.getElementById(elem + "-container");
  var element_bild = document.getElementById("img" + elem);
  var element_folder = document.getElementById("folder" + elem);
  var temparray = new Array;

  if (!element)
  {
    window.setTimeout("closeAllSubElems('" + elem + "');", 100);  
  }
  else
  {
    if (!element_bild)
    {
      element_bild.src = pfeil_zu; 
    }
    if (element_folder)
    {
      element_folder.src = folder_zu; 
    }

    element.style.display = "none";   

    if (element.parentNode.parentNode.id!="tree")
    {
      for (var i=0; i < element.parentNode.parentNode.subfolders.length; i++)
      {
        if (element.parentNode.parentNode.subfolders[i]!=elem)
        {
          temparray[temparray.length]=element.parentNode.parentNode.subfolders[i];
        }
      }

      element.parentNode.parentNode.subfolders=temparray;
    }   

    if (element_bild)
    {
      element_bild.src = pfeil_zu ;
    }
    if (element_folder)
    {
      element_folder.src = folder_zu ;
    }    

    var currsubfolders = new Array;
    currsubfolders=element.subfolders;

    if (currsubfolders)
    {
      var subcount=currsubfolders.length;
      for (var i=0;i<subcount;i++)
      {
        if (currsubfolders[i])
          closeAllSubElems(currsubfolders[i]);        
      }
    }    
  }
}


function toggle(elemid)
{  
  //return;
  var element = document.getElementById(elemid + "-container");
  var element_bild = document.getElementById("img" + elemid);
  var element_folder = document.getElementById("folder" + elemid);
  
  if (!element || !element_bild)
  {
    window.setTimeout("toggle('" + elemid + "');", 100);  
  }
  else
  {    
    var achild=element.lastChild;  

    // get child node
    if (isVisible(element))
    { 
      closeAllSubElems(elemid);             
    }        
    else 
    {
      element_bild.src = pfeil_auf;    
      if (element_folder)
      {
        element_folder.src = folder_auf; 
      }

      element.style.display = "block";    
      
      if (element.parentNode.parentNode.id!="tree")
      {
        if (typeof (element.parentNode.parentNode.subfolders) == "undefined")
        {
          element.parentNode.parentNode.subfolders=new Array();
        }
        element.parentNode.parentNode.subfolders[element.parentNode.parentNode.subfolders.length]=elemid;
      }
    } 
  }    
}

function isVisible(element){
   if(element == null) return false;
   if(element.style.display == "none" || element.style.display == "")
   {
      return false;
   }
   else
   {
      return true;
   }
}

function expandParents(element) 
{
  if (element.parentNode && element.parentNode.nodeName == "DIV")
  {
    var element_container = element.parentNode;
    var element = element_container.parentNode;
  
    var element_bild = document.getElementById("img" + element.id);
    var element_folder = document.getElementById("folder" + element.id);
    
    if (element_bild)
    {
      element_bild.src = pfeil_auf;
    }
    if (element_folder)
    {
      element_folder.src = folder_auf;
    }    
    
    element_container.style.display = "block";

    if (element.parentNode.id!="tree")
    {
      if (typeof (element.parentNode.subfolders) == "undefined")
      {
        element.parentNode.subfolders=new Array();
      }
      element.parentNode.subfolders[element_container.parentNode.parentNode.subfolders.length]=element.id;
    }
    
    expandParents(element);
  }  
}

function highLightT(tagname)
{  
  setTreeInactive();
  found = false;  
  for (var i=0;hrefElem = document.getElementsByName(tagname)[i];i++)
  {    
    found = true;
    var highLightElem = hrefElem.parentNode;
    expandParents(highLightElem);    
    hrefElem.style.backgroundColor = "#D6EBEF";       
  }  
  if (found)
  {
    return 0;
  }
  else
  {
    return 1;
  }
}

// optimized search, input array has to be sorted
function findPageAdress (pattern, nameArray, adressArray)
{
  var pattern = utf8ToHex (pattern);
  
  var delta_i=Math.round(Math.sqrt(nameArray.length));

  for(var i = 0; i < nameArray.length; i=i+delta_i)
  {        
    var instid = unescape(nameArray[i]);
    var guid;
          
    if (escape(unescape(instid)) >= escape(unescape(pattern)))
    {
      while (i>=0)
      {                     
        instid = unescape(nameArray[i]);

        if (escape(unescape(instid)) == escape(unescape(pattern)))
        {
          return (adressArray[i]);
        }     
        if (i==0)
        {
          return "";
        }
        i--; 
      }
    }
    
    if ((i+delta_i) >= nameArray.length)
      delta_i = (nameArray.length - i - 1);
  } 
  return "";
}


function setTreeInactive()
{
  var topElem = document.getElementById("0");
  while (topElem!=null && b_closetree) 
  {
    closeAllSubElems(topElem.id);
    topElem = topElem.nextSibling;
  }
  
  for (var i=0;hrefElem = document.getElementsByTagName("A")[i];i++)
  {    
    hrefElem.style.backgroundColor = "";    
  } 
}

function loadPage(name, target)
{  
  if (window == top)
  {
    oObj = opener; 
  }
  else
  {
    oObj = parent;
  }

  if (!oObj || !oObj.top.control|| !oObj.top.menu || !oObj.top.model)
  {
    window.setTimeout("loadPage('" + name + "','" +  target + "');", 100);  
  }
  else
  {
    if (oObj.top.control.gContentReload == false)
    {
      oObj.top.control.gContentReload = true;
      oObj.top.menu.highLightT(parent.control.highlighted);
      return
    }

    if (target == "InstanceWindow")
    {
      pageAdress = findPageAdress (name, oObj.top.inst_ID, oObj.top.inst_Addr);    
      if (pageAdress == "")
      {
        pageAdress = findPageAdress (name, oObj.top.mod_ID, oObj.top.mod_Addr);    
      }    
    }
    else
    {
      pageAdress = "../" + name + "/" + name + ".htm";  
    }  
    if (pageAdress == "")
    {
      return 0;
    }

    if (target == "InstanceWindow")
    {

      oObj.top.current_instance = name;
      oObj.parent.control.awin = window.open(pageAdress, "InstanceWindow", "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes");
      oObj.parent.control.awin.focus();
    }
    else
    {
      if (typeof(parent.model) == "undefined")
      {
        window.setTimeout("loadPage('" + name + "', '" + target + "');", 100);
      }
      else
      {
        oObj.top.model.location.href = pageAdress;
      }
    }
  }
}

function loadPageDbl(name1, name2, target1, target2)
{  
  if (window.name == "InstanceWindow")
  {
    oObj = opener; 
  }
  else
  {
    oObj = parent;
  }
  if (!oObj || !oObj.top.control || !oObj.top.menu || !oObj.top.model)
  {
    window.setTimeout("loadPageDbl('" + name1 + "', '" + name2 + "', '" + target1 + "', '" + target2 + "');", 100);  
  }
  else
  {
    if (oObj.top.control.gContentReload == false)
    {
      oObj.top.control.gContentReload = true;
      oObj.top.menu.highLightT(oObj.top.control.highlighted);
      return
    }


    if (target1 == "model")
    {
      if (name1 != 'ID')
      {
        pageAdress = "../" + name1 + "/" + name1 + ".htm";  
        oObj.top.model.location.href = pageAdress; 
      }
    }

    if (target2 == "model")
    {
      if (name2 != 'ID')
      {
        pageAdress = "../" + name1 + "/" + name1 + ".htm";  

        oObj.top.model.location.href = pageAdress;
      }
    }  

    if (target1 == "InstanceWindow")
    {
      if (name1 != 'ID')
      {           
        oObj.top.current_instance = name1;

        pageAdress = findPageAdress (name1, top.inst_ID, oObj.top.inst_Addr);  
        if (pageAdress == "")
        {
          pageAdress = findPageAdress (name1, top.mod_ID, oObj.top.mod_Addr);    
        }     
        if (oObj.top.control.awin!=0)
          oObj.top.control.awin.close();
        oObj.top.control.awin = window.open(pageAdress, target1, "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes,left=0,top=300");
        //awin.focus();             
      }
    }

    if (target2 == "InstanceWindow")
    {
      if (name2 != 'ID')
      {          
        oObj.top.current_instance = name2;

        pageAdress = findPageAdress (name2, oObj.top.inst_ID, oObj.top.inst_Addr);  
        if (pageAdress == "")
        {
          pageAdress = findPageAdress (name2, oObj.top.mod_ID, oObj.top.mod_Addr);    
        }
        if (oObj.top.control.awin!=0)
          oObj.top.control.awin.close();
        oObj.top.control.awin = window.open(pageAdress, target2, "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes,left=0,top=300");
        //awin.focus();            
      }
    }   
  }
}
