Xoffset= 10;    // modify these values to ...
Yoffset= 0;    // change the Popup position.
var contextMenuUsed = false;
var inHotSpotRegion = false;

newX = 0;
newY = 0;

function DoContextMenu(target)
{
  obj = document.getElementById("dek");
  if (!obj)
  {
    window.setTimeout("DoContextMenu('" + target + "');", 100);          
  }
  else
  {
    KillPopup();
    if (obj.style.visibility == "visible")
    {
      obj.style.visibility = "hidden";
    }

    // next CM is empty (has only Detail entry but no refs)
    if (nextMen == "")
    {
      // show instance page directly
      doDefault(target, 'inst')  
      return
    }

    contextMenuUsed = true;
    ActualizeContextMenu();
    contextMenuUsed = false;

    return false;
  }
}

function GetMouse(Event)
{
  if (moz)
  {
    oEvent = Event;
  }
  else
  {
    oEvent = event;
  }
  newX = oEvent.clientX;
  newY = oEvent.clientY;

  oMov = document.getElementById("mov");

  if (!oMov)
  {
    window.setTimeout("GetMouse(Event);", 100);            
  }
  else
  {
    var rightedge = document.body.clientWidth - newX;
    var bottomedge = document.body.clientHeight - newY;

    if (! document.events)
    {
      return;
    }
    else
    {
      //if the horizontal distance isn't enough to accomodate the width of the context menu
      if (rightedge < oMov.offsetWidth)
      {
        //move the horizontal position of the menu to the left by its width
       oMov.style.left = document.body.scrollLeft + newX - oMov.offsetWidth - Xoffset;
      }
      else
      {
        //position the horizontal position of the menu where the mouse was clicked
        oMov.style.left=document.body.scrollLeft + newX + Xoffset;
      }

      //same concept with the vertical position
      if (bottomedge<oMov.offsetHeight)
      {
        oMov.style.top=document.body.scrollTop + newY - oMov.offsetHeight + Yoffset;
      }
      else
      {
        oMov.style.top=document.body.scrollTop + newY - Yoffset;
      }
    }
  }
}

function ActualizeContextMenu()
{
  if (moz)
  {
    oEvent = Event;
  }
  else
  {
    oEvent = event;
  }

  obj = document.getElementById("dek");

  if (!obj || !document.body)
  {
    window.setTimeout("GetMouse(Event);", 100);            
  }
  else
  {
    //Find out how close the mouse is to the corner of the window
    var rightedge  = document.body.clientWidth - newX;
    var bottomedge = document.body.clientHeight - newY;
    var xOffSet = 5;

    //hide old Menu
    if (obj.style.visibility == "visible")
    {
      obj.style.visibility = "hidden";
      if (!contextMenuUsed && !inHotSpotRegion)
      {
        return;
      }
    }
    else
    if (!contextMenuUsed && !inHotSpotRegion)
    {
      return;
    }

    if (contextMenuUsed && nextMen != "")
    {
      obj.innerHTML = nextMen;
      obj.style.visibility = "visible";
    }

    //alert("ACT");
    obj = document.getElementById("dek");

    //if the horizontal distance isn't enough to accomodate the width of the context menu
    if (rightedge < obj.offsetWidth)
    {
      //move the horizontal position of the menu to the left by its width
      obj.style.left=document.body.scrollLeft + newX - obj.offsetWidth - xOffSet;
    }
    else
    {
      //position the horizontal position of the menu where the mouse was clicked
      obj.style.left=document.body.scrollLeft + newX + xOffSet;
    }

    //same concept with the vertical position
    if (bottomedge<obj.offsetHeight)
    {
      alt_y = document.body.scrollTop + newY - obj.offsetHeight;
      if (alt_y < 0)
      {
        obj.style.top=5;
      }
      else
      {
      obj.style.top=document.body.scrollTop + newY - obj.offsetHeight;
    }
    }
    else
    {
      obj.style.top=document.body.scrollTop + newY;
    }
  }
}

function DoMouseOver(instID, sInstID)
{
  //alert(instID);
  inHotSpotRegion = true;
  FillNextContextMenu(instID); 
  msg = eval(sInstID + "D");
  //alert(msg);
  obj = document.getElementById("dek");
  if (!obj)
  {
    window.setTimeout("DoMouseOver('" + instID + "','" + sInstID + "')",100);
  }
  else
  {
		if ((typeof obj.style.show == "undefined") || (obj.style.show != "visible"))
		{
			Popup (msg);  
		}
  }
}


function DoMouseOverSkip(instID, sInstID)
{
  //alert(instID);
  inHotSpotRegion = true;
  FillNextContextMenu(instID); 
}



function DoMouseOut()
{
  inHotSpotRegion = false;
  ResetNextMenu();
  KillPopup();
}

function FillNextContextMenu (instID)
{
  if (!document.getElementById(instID))
  {
    window.setTimeout("FillNextContextMenu('" + instID + "');", 100);              
  }
  else
  {
    nextMen = document.getElementById(instID).innerHTML;
  }
}

function ResetNextMenu()
{
  nextMen = "";
  obj = document.getElementById("dek");
  if (!obj)
  {
    window.setTimeout("ResetNextMenu();", 100);              
  }
  else
  {
    obj.visibility = "hidden";
    contextMenuUsed = false;
  }
}

function getUrlNH(s)
{
  begin = s.indexOf('HREF=') + 6;
  if (begin == 5)
    return "";

  end = s.indexOf('"', begin);
  return s.substring(begin, end);
}

function CMopen(target, mode)
{
  if (!parent.model)
  {
    window.setTimeout("CMopen('" + target + "'," + mode + ");", 100);              
  }
  else
  {
    if (mode == 1) // model ref
    {
      parent.model.location.href = target;
    }
    else // object ref
    {
      ins = window.open(target, "InstanceWindow", "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes");
      ins.focus();
    }
  }
}

function doClick(Event)
{
  if (!inHotSpotRegion)
  {
    ActualizeContextMenu();
  }
}

function doDefault(target, type)
{
  oDek = document.getElementById("dek");
  if (!parent.model || !oDek)
  {
    window.setTimeout("doDefault('" + target + "','" + type + "');", 100);              
  }
  else
  {
    oDek.style.visibility = "hidden";
    if (type == 'inst')
    {
      ins = window.open(target, "InstanceWindow", "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes");
      ins.focus();

    }
    else
    {
      parent.model.location.href = target;
    }
  }  
}