//***********************************************
//* ADOSCROLLER 1.0
//***********************************************
//* Standard Scroller modified and optimized.
//*
//* Last modification: 2004-11-17
//*
//* Author: Boris Gregorcic
//*         BOC Information Systems GmbH
//*
//***********************************************

// CONFIGURATION SECTION


//---------------------------------------------
// the width and height of the scroller window
// should be the same as the width and height
// of the frame in which the AdoScroller.htm
// is loaded.

scroller_window_width = 0;
scroller_window_height = 0;

//---------------------------------------------
// The standard header space defines the space
// from the top of the model page to the actual
// upper border of the model graphic. Normally 
// the header contains the model name, however
// you should make sure, that it is always exactly 
// the height specified here.
// Therefore you should also put possible text
// emitted in the header inside a <NOBR></NOBR>
// to avoid line breaks and changes in the header 
// height when resizing the browser window

std_header_space = 0;
std_footer_space = 90;


//---------------------------------------------
// Scrollbar defines the width of the space
// allocated for a scrollbar. This is relevant
// if the model frame has scrolling enabled,
// which is of course true in most of the cases

scrollbar = 14;

//---------------------------------------------
// adoScrollerFrame names the frame where the
// AdoScroller.htm is been loaded. If you don't 
// use the default frame name 'ado_scroller',
// change this variable to parent.<framename>.

 q = 0; // don't ask ... was necessary in seperate window mode
       // set to 4 there 

/***********************************/

selIn = false;
newX = 0;
newY = 0;
selDrag = false;

init_vars();

//---------------------------------------------
function getSelectionX()
//---------------------------------------------
{
  return selection_x;
}

//---------------------------------------------
function GetAdoMouse(Event)
//---------------------------------------------
{
  oldX = newX;
  oldY = newY;
  
  if (moz)
  {
    oEvent = Event;
  }
  else
  {
    oEvent = event;
  }

  newX = oEvent.clientX;
  newY = oEvent.clientY;
  if (selDrag)
  {    
    drag(newX - oldX, newY - oldY);
  }
}


//---------------------------------------------
function drag(deltaX, deltaY)
//---------------------------------------------
{
  oObj = document.getElementById("Layer1"); 
  if (!oObj || !parent.ado_scroller)
  {
    window.setTimeout("drag(" + deltaX + "," + deltaY + ");", 100);
  }
  else
  {
    if (!parent.ado_scroller.factor)
    {
      window.setTimeout("drag(" + deltaX + "," + deltaY + ");", 100);
    }
    else
    {
      oX = oObj.style.left;
      oY = oObj.style.top;  
      oX = Number(oX.substring(0, oX.length - 2));
      oY = Number(oY.substring(0, oY.length - 2));

      if ((oX + deltaX >= 0) && (oX + deltaX + selection_x <= scroller_window_width))
      {
        oObj.style.left = oX + deltaX;
      }
      if ((oY + deltaY >= 0) && (oY + deltaY + selection_y <= scroller_window_height))
      {
        oObj.style.top = oY + deltaY;
      }
      myScrollTo(oX*parent.ado_scroller.factor, oY*parent.ado_scroller.factor);  
    }
  }
}

//---------------------------------------------
function init_vars()
//---------------------------------------------
{
  if (!parent.ado_scroller)
  {
    window.setTimeout("init_vars();",100);
  }
  else
  {
    oAdoScroller = parent.ado_scroller.document.getElementById("AdoScrollerBody");
    if (!oAdoScroller)
    {
      window.setTimeout("init_vars();",100);
    }
    else
    {
      scroller_window_width = oAdoScroller.offsetWidth;
      scroller_window_height = oAdoScroller.offsetHeight;
    }
  }
}

//---------------------------------------------
function actualizeAS()
//---------------------------------------------
{
  if (self != top)
  {
    if (!parent.ado_scroller)
    {
      window.setTimeout("actualizeAS();",100);    
    }
    else
    {
      parent.ado_scroller.location.reload();
      window.setTimeout("initAS()",500);
    }
  }
}

//---------------------------------------------
function resizeAS()
//---------------------------------------------
{
  if (!parent.model)
  {
    window.setTimeout("resizeAS();",100);      
  }
  else
  {
    initAS();
  }
}

//---------------------------------------------
function reloadAS()
//---------------------------------------------
{
  if (self != top)
  {
    if (!parent.ado_scroller)
    {
      window.setTimeout("reloadAS();",100);      
    }
    else
    {
      parent.ado_scroller.location.reload();
    }
  }
}

//---------------------------------------------
function initAS()
//---------------------------------------------
{
  init_vars();
  if (!parent.model)
  {
    window.setTimeout("initAS();", 100);
  }
  else
  {
    oMg = parent.model.document.getElementById("modelgraphic");
    oMb = parent.model.document.getElementById("modelbody");
    if (!oMg || !oMb)
    {      
      window.setTimeout("initAS();", 100);
    }
    else
    {
      x_overflow = false;
      y_overflow = false;
      
      // tabular mode => no use for AdoScroller
      if (oMg == null)
      {
        hide_resize();
        return;
      }
      else
      {
        show_resize();
      }
      image = oMg.src;
      image_x = oMg.width;
      image_y = oMg.height;

      if (moz)
      {
        visible_x = parent.model.innerWidth;
        visible_y = parent.model.innerHeight;        
      }
      else
      {
        visible_x = oMb.offsetWidth;
        visible_y = oMb.offsetHeight;    
      }

      if (image_x > visible_x)
      {
        x_overflow = true;
        maxModelWidth = image_x;
      }
      else
      {
        maxModelWidth = visible_x;
      }
      if ((std_header_space + image_y + std_footer_space) > visible_y)
      {
        Y_overflow = true;
        maxModelHeight = std_header_space + image_y + std_footer_space;
        if (x_overflow)
        {
          maxModelHeight += scrollbar;
        }
        maxModelWidth = maxModelWidth + scrollbar;
      }
      else
      {
        maxModelHeight = visible_y;
      }    
      factor_x = (maxModelWidth / scroller_window_width);
      factor_y = (maxModelHeight / scroller_window_height);
      factor = (factor_x > factor_y)?factor_x:factor_y;
      small_x = Math.round(image_x / factor);
      small_y = Math.round(image_y / factor);
      small_y_top = Math.round(std_header_space / factor);
      small_y_bottom = Math.round(std_footer_space / factor);

      tX = visible_x;
      
      var ama_x = maxModelWidth;
      var ama_y = maxModelHeight;
      
      if (y_overflow)
      {
        tX -= scrollbar;
        ama_x -= scrollbar;
      }
      tX -= scrollbar;
      ama_x -= scrollbar;
      // for whatever reason we have to reduce by another scrollbarwidth
      //tX -= scrollbar;
      tY = visible_y;
      if (x_overflow)
      {
        tY -= scrollbar;
        ama_y -= scrollbar;
      }
      tY -= scrollbar;
      ama_y -= scrollbar;
      // for whatever reason we have to reduce by another scrollbarwidth
      //tY -= scrollbar;
      
      parent.ado_scroller.selection_x = Math.floor(tX / factor);
      parent.ado_scroller.selection_y = Math.floor(tY / factor);
      
      parent.ado_scroller.AMA_y = Math.floor(ama_y / factor);
      parent.ado_scroller.AMA_x = Math.floor(ama_x / factor);
      
      parent.ado_scroller.factor = factor;
      initAdoScroller();        
    }
  } 
}
/***********************************/

//---------------------------------------------
function AS_position()
//---------------------------------------------
{
  if (parent.ado_scroller.document.getElementById('Layer1') && (parent.control.isInScrollWindow == 0))
  {
    parent.ado_scroller.document.getElementById('Layer1').style.top = parseInt(document.body.scrollTop/parent.ado_scroller.factor);
    parent.ado_scroller.document.getElementById('Layer1').style.left = parseInt(document.body.scrollLeft/parent.ado_scroller.factor);
  }
}

//---------------------------------------------
function initAdoScroller()
//---------------------------------------------
{
  if (! parent.ado_scroller)
  {
    window.setTimeout("initAdoScroller();", 100);
  }
  else
  {
    if (! parent.ado_scroller.document)
    {
      window.setTimeout("initAdoScroller();", 100);
    }
    else
    {
      cont = parent.ado_scroller.document.getElementById("container");
      if (! cont)
      {
        window.setTimeout("initAdoScroller();", 100);
      }
      else
      {        
        if ((! parent.ado_scroller.selection_x) || (! parent.ado_scroller.selection_y))
        {
          window.setTimeout("initAdoScroller();", 100);
        }
        else
        {        
          content = ("<table cellpadding=\"0\" cellspacing=\"0\" id=\"ASModelArea\" width=\"" + parent.ado_scroller.AMA_x + "\" height=\"" + parent.ado_scroller.AMA_y + "\"><tr><td><img src=\"" + image + "\" width=\"" + small_x + "\" height=\"" + small_y + "\" border=\"0\" style=\" margin-top:" + small_y_top + "px;\"></td></tr></table>");
          content += ("<div id=\"Layer1\" style=\"position:absolute; width:" + parent.ado_scroller.selection_x + "px; height:" + parent.ado_scroller.selection_y + "px; z-index:1; left: 0px; top: 0px\" ");
          content += ("onMouseOver=\"selectionIn();\" onMouseOut=\"selectionOut();\" ");
          content += ("onMouseDown=\"startDrag();\" onMouseUp=\"endDrag();\">");
          content += ("<table width=\"" + parent.ado_scroller.selection_x + "\"  height=\"" + parent.ado_scroller.selection_y + "\" style=\"cursor:move;border:1px solid #FF0000\">");
          content += ("  <tr border=\"0\">");
          content += ("    <td style=\"border:0px;\">&nbsp;</td>");
          content += ("  </tr>");
          content += ("</table>");
          content += ("</div>");    
          cont.innerHTML = content;
        }
      }
    }
  }
}

//---------------------------------------------
function selectionIn()
//---------------------------------------------
{
  selIn = true;
}

//---------------------------------------------
function endDrag()
//---------------------------------------------
{
  parent.control.isInScrollWindow = 0;
  selDrag = false;
}

//---------------------------------------------
function startDrag()
//---------------------------------------------
{
  parent.control.isInScrollWindow = 1;
  selDrag = true;
}
//---------------------------------------------
function selectionOut()
//---------------------------------------------
{
  selIn = false;
  endDrag();
}

//---------------------------------------------
function myScrollTo(x,y)
//---------------------------------------------
{
  if (!parent.model)
  {
    window.setTimeout("myScrollTo(" + x + "," + y + ");", 100);
  }
  else
  {
    parent.model.scrollTo(Math.round(x),Math.round(y));
  }
}

