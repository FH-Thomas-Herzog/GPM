//
// extracts out of an string the plain link without href anker.
//
function getParalellUrl(s)
{
  begin = s.indexOf('HREF=');

  if (begin == -1)
  {
    return "";
  }
  else
  {
    begin += 6;
    end    = s.indexOf('"', begin);

    return s.substring(begin, end);
  }
}

//
// loads the pages (on click on ATTRSPOTS or HOTSPOTS)
//
function loadPage(mod_lnk, ins_lnk)
{
  if (mod_lnk == "")
  {
    return;
  }

  if (top.origin == "Delta Generierung")
  {
    mod_lnk = mod_lnk.substring(0, mod_lnk.lastIndexOf("."))+"1.htm";
  }

  if (ins_lnk == "")
  {
    if (!top.frames.model)
    {
      window.setTimeout("loadPage('" + mod_lnk + "','" + ins_lnk + "');", 100);              
    }
    else
    {
      top.frames.model.location=mod_lnk;
    }
  }
  else
  {
    InstanceWindow = window.open(ins_lnk, "InstanceWindow", "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes,left=0,top=300");
    InstanceWindow.focus();
  }
}

function loadPageNew(url)
{
  if (url == "")
  {
    return;
  }

  InstanceWindow = window.open(url, "InstanceWindow", "scrollbars=yes,resizable=yes,width=400,height=600,dependent=yes,left=0,top=300");
  InstanceWindow.focus();
}

