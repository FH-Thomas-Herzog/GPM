var instID = new Array();
var instIDAddr = new Array();

var instName = new Array();
var instNameAddr = new Array();

var modelName = new Array();
var modelNameAddr = new Array();

var search_is_set=-1;

//
// Open model print view in new window
//
function OpenPrintView()
{
  if (!top.model)
  {
    window.setTimeout("OpenPrintView();", 100);            
  }
  else
  {
    var currentModelPage="";
    var currentPrintPage="";

    if (top.model.prnpage)
    {
      currentPrintPage = top.model.prnpage;
    }
    else
    {
      currentPrintPage = top.model.location.href;
    }

    PrintWindow = window.open(currentPrintPage, "Print", "scrollbars=yes,resizable=yes,width=600,height=600,menubar=yes,left=300,top=20");
    //PrintWindow.print();
  }
}




//
// Convert a unicode to hex ascii
//
function utf8ToHex (source)
{
  source = source.replace(/&#32;/g,  "%20");
  source = source.replace(/&#34;/g,  "%22");
  source = source.replace(/&#37;/g,  "%25");
  source = source.replace(/&#39;/g,  "%27");
  source = source.replace(/&#44;/g,  "%2C");
  source = source.replace(/&#46;/g,  "%2E");
  source = source.replace(/&#92;/g,  "%5C");
  source = source.replace(/&#8364;/g,"%80");
  source = source.replace(/&#40;/g,  "%28");
  source = source.replace(/&#41;/g,  "%29");
  return source;
}

//
// Convert a unicode to hex ascii
//
function maskTags(source)
{
  source = source.replace('<',  "&lt;");
  source = source.replace('>',  "&gt;");
  return source
}

//
// Searches HTML-Page for a given instance ID
//
function findID(pattern)
{
  pattern = utf8ToHex(pattern);

  for(i = 0; i < instID.length; i++)
  {
    if(escape(unescape(instID[i])) == escape(unescape(pattern)))
    {
      return ("<A HREF=\"" + instIDAddr[i] + "\" target=\"instance\">");
    }
  }

  alert ("[Link-01]\nDie Information zum gesuchten Objekt '" + unescape(pattern) + "' wurde nicht gefunden!\nDieses Problem kann u.a. durch das Umbenennen von referenzierten Objekten entstehen. Falls Sie referenzierte Objekte umbenannt haben, sollten Sie den gesamten Modellbestand neu generieren.");
  return "";
}


//
// Searches HTML-Page for a given instance ID
//
function findInstance(pattern)
{
  pattern = utf8ToHex(pattern);

  for(i = 0; i < instName.length; i++)
  {
    if(escape(unescape(instName[i])) == escape(unescape(pattern)))
    {
      return ("<A HREF=\"" + instNameAddr[i] + "\" target=\"instance\">");
    }
  }

  alert ("[Link-02]\nDie Information zum gesuchten Objekt '" + unescape(pattern) + "' wurde nicht gefunden!\nDieses Problem kann u.a. durch das Umbenennen von referenzierten Objekten entstehen. Falls Sie referenzierte Objekte umbenannt haben, sollten Sie den gesamten Modellbestand neu generieren.");
  return "";
}


//
// Searches HTML-Page for a given instance ID
//
function findModel(pattern)
{
  pattern = utf8ToHex(pattern);

  for(i = 0; i < modelName.length; i++)
  {
    if(escape(unescape(modelName[i])) == escape(unescape(pattern)))
    {
      return ("<A HREF=\"" + modelNameAddr[i] + "\" target=\"model\">");
    }
  }

  alert ("[Link-03]\nDie Information zum gesuchten Objekt '" + unescape(pattern) + "' wurde nicht gefunden!\nDieses Problem kann u.a. durch das Umbenennen von referenzierten Objekten entstehen. Falls Sie referenzierte Objekte umbenannt haben, sollten Sie den gesamten Modellbestand neu generieren.");
  return "";
}


//
// Searches HTML-Page for a given instance ID
//
function findParallelLoadModel(pattern)
{
  pattern = utf8ToHex(pattern);

  for(i = 0; i < modelName.length; i++)
  {
    if(escape(unescape(modelName[i])) == escape(unescape(pattern)))
    {
      return ("'<A HREF=\"" + modelNameAddr[i] + "\">bla</A>'");
    }
  }

  alert ("[Link-04]\nDie Information zum gesuchten Objekt '" + unescape(pattern) + "' wurde nicht gefunden!\nDieses Problem kann u.a. durch das Umbenennen von referenzierten Objekten entstehen. Falls Sie referenzierte Objekte umbenannt haben, sollten Sie den gesamten Modellbestand neu generieren.");
  return "";
}


//
// extracts out of an string the 'href=...' anker.
//
function getUrl(s)
{
  begin = s.indexOf('HREF=');

  if (begin == -1)
  {
    return "";
  }
  else
  {
    end = s.indexOf('"', begin + 6);

    if (s.indexOf('$$$instance$$$') == -1)
    {
      return s.substring(begin, end + 1);
    }
    else
    {
      return s.substring(begin, end + 1) + ' target=instance';
    }
  }
}

//
// extracts out of a string an URL without the 'href=...' anker
//
function getUrl2(s)
{
  begin = s.indexOf('HREF=');

  if (begin == -1)
  {
    return "";
  }
  else
  {
    end = s.indexOf('"', begin + 6);
    return s.substring(begin + 6, end);
  }
}

//////////////////////////////////////////////////////////////////
// tree highlighting
//////////////////////////////////////////////////////////////////
// -> frame level
//////////////////////////////////////////////////////////////////
function setCustTreeMenuByLink()
{
  var fileURI = document.location.pathname;
  var nBegin  = fileURI.lastIndexOf("\\") + 1;

  if (nBegin < 0)
  {
    nBegin  = fileURI.lastIndexOf("/") + 1;
  }

  if (nBegin < 0)
  {
    return;
  }

  fileURI = fileURI.substring(nBegin, fileURI.length);

  if (self == top)
  {
    if (opener)
    {
      opener.top.highLightByLink(fileURI, true);
    }
  }

  top.highLightByLink(fileURI, true);
}




//
// close 'follow reference'-'show notebook'-menu
//
function KillMenu()
{
  if (document.layers)
  {
  // for Netscape 4.0
    if (!document.nb)
    {
      window.setTimeout("KillMenu();", 100);            
    }
    else
    {
      document.nb.visibility = "hide";
    }
  }
  else
  {
    if (!document.getElementById("nb"))
    {
      window.setTimeout("KillMenu();", 100);            
    }
    else
    {
      document.getElementById("nb").style.visibility = "hidden";
    }
  }
}

//
// opens popup window
//
function Popup(msg)
{
  if(msg.length==0)
  {
    return; //empty attribute
  }

  if (!document.getElementById("dek"))
  {
    window.setTimeout("Popup('" + msg + "');", 100);              
  }
  else
  {
    if((iex || moz) && (document.getElementById("dek").style.visibility == "hidden")
      || (document.getElementById("dek").style.visibility == ""))
    {
    // for MS-Internet Explorer 4.0 and higher
      var content="<TABLE CLASS='table'><TD ALIGN=left>"+msg+"</TD></TABLE>";
      document.getElementById("mov").innerHTML = content;
      document.getElementById("mov").style.display = "block";
    }
  }
}

//
// closes popup window
//
function KillPopup ()
{
  oDek = document.getElementById("mov");
  if (!oDek)
  {
    window.setTimeout("KillPopup();", 100);              
  }
  else
  {
    oDek.style.display = "none";
  }
}

Xoffset= 10;    // modify these values to ...
Yoffset= 0;    // change the Popup position.

function showStatusInfo(sStatusText)
{
  try
  {
    oFoo = document.getElementById("statusInfo");
  }
  catch(e)
  {
    return;
  }
  
  oFoo.innerHTML = maskTags(sStatusText);
  oFoo.style.position = "absolute";
  oFoo.style.left=0;
  oFoo.style.top=0;
  oFoo.style.display = "block";
}

function destroyStatusInfo()
{
  try
  {
    oFoo = document.getElementById("statusInfo");
  }
  catch(e)
  {
    return;
  }
  
  oFoo.style.display = "none";
}