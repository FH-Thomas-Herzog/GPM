document.write("<style type='text/css'>.xFenster {display:none}</style>");

xAddEventListener(window, 'load',
  function() { 
    /*
    new xFenster(clientId, iniTitle, iniUrl, iniX, iniY, iniW, iniH, miniW, fenceId, conPad, conBor, cliBor,
             enMove, enResize, enMinimize, enMaximize, enClose, enStatus, enFixed,
             fnMove, fnResize, fnMinimize, fnMaximize, fnRestore, fnClose, fnFocus, fnLoad,
             clsCon, clsCli, clsTitlebar, clsTitlebarFocused, clsStatusbar, clsStatusbarFocused,
             clsResizeIcon, clsMinimizeIcon, clsMaximizeIcon, clsRestoreIcon, clsCloseIcon,
             txtResize, txtMin, txtMax, txtRestore, txtClose);
    */
	var iniX = 2;
	var iniY = 78;
	var iniW = 280;
	var iniH = xClientHeight()-iniY-2;
	var miniW = 280;
     
	new xFenster('navigator', 'Navigator', null, iniX, iniY, iniW, iniH, miniW, null, 0, 1, 0,
				true, true, true, true, false, true, true,
				null, null, null, null, null, null, null, null,
				'xfCon', 'xfClient', 'xfTBar', 'xfTBarF', 'xfSBar', 'xfSBarF',
				'xfRIco', 'xfNIco', 'xfMIco', 'xfOIco', 'xfCIco',
				'Resize', 'Minimize', 'Maximize', 'Restore', 'Close');
				
	xFenster.instances.navigator.minimize();
  }, false
);